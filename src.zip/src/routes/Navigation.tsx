import React from "react";
import { Outlet } from "react-router-dom";
import NavLeft from "../Components/NavLeft.tsx";
import Analytics from "./Analytics.tsx";

export default function Navigation() {
  return (
    <div>
      <NavLeft>
        <Outlet></Outlet>
      </NavLeft>
    </div>
  );
}
