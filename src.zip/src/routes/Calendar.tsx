import React from "react";
import CalendarComponent from "../Components/calendar/CalendarComponent.tsx";

export default function Calendar() {
  return (
    <div>
      <CalendarComponent />
    </div>
  );
}
