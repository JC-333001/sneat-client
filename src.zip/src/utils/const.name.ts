export const DASHBOARD = "Dashboard";
export const EMAIL = "Email";
export const CHAT = "Chat";
export const ANALYTICS = "Analytics";
export const CRM = "CRM";
export const ECOMMERCE = "eCommerce";
export const CALENDAR = "Calendar";
